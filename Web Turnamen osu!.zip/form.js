const form = document.querySelector('form');
const namaInput = document.getElementById('nama');
const emailInput = document.getElementById('email');
const jkInput = document.getElementsByName('jk');
const hobiInput = document.getElementsByName('hobi');
const kategoriInput = document.getElementById('kategori');
const pesanInput = document.getElementById('pesan');

form.addEventListener('submit', function(e) {
  e.preventDefault();

  const data = {
    nama: namaInput.value,
    email: emailInput.value,
    jk: '',
    hobi: [],
    kategori: kategoriInput.value,
    pesan: pesanInput.value
  };

  for (let i = 0; i < jkInput.length; i++) {
    if (jkInput[i].checked) {
      data.jk = jkInput[i].value;
      break;
    }
  }

  for (let i = 0; i < hobiInput.length; i++) {
    if (hobiInput[i].checked) {
      data.hobi.push(hobiInput[i].value);
    }
  }

  sessionStorage.setItem('formData', JSON.stringify(data));

  alert('Data telah disimpan');
  form.reset();
});
