const form = document.getElementById("form");
const nama = document.getElementById("nama");
const pass = document.getElementById("pass");

form.addEventListener("submit", function (e) {
    e.preventDefault();

    const loc_nama = localStorage.getItem('nama');
    const loc_pass = localStorage.getItem('pass');

    // Menemukan pengguna berdasarkan nama dan password yang diinputkan
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const foundUser = users.find(user => user.nama === nama.value == loc_nama && pass.value == loc_pass);

    if (foundUser){
        alert("Berhasil Masuk");
        window.location.href = "beranda.html";
    }else{
        alert("Nama atau Password salah");
        window.location.href = "beranda.html";
    }
});