const form = document.getElementById("form");

function daftar(e) {
  e.preventDefault();
  const nama = document.getElementById('nama');
  const email = document.getElementById('email');
  const pass = document.getElementById('pass');

  localStorage.setItem("nama", nama.value);
  localStorage.setItem("email", email.value);
  localStorage.setItem("pass", pass.value);

  // Menambahkan data pengguna ke dalam array yang tersimpan pada sessionStorage
  const users = JSON.parse(sessionStorage.getItem('users') || '[]');
  users.push({
    nama: nama.value,
    email: email.value,
    pass: pass.value,

  });
  sessionStorage.setItem('users', JSON.stringify(users));

  alert("Berhasil daftar");
  window.location.href = "index.html";
}

form.addEventListener('submit', daftar);